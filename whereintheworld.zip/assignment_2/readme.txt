what's been done right

The POST /sendlocation, get /locations.json, and / are all done correctly, but I didn't have time to do the redline stuff

who I collaborated with:

no one, I did this by myself

Time spent:

probably about 4 hours
